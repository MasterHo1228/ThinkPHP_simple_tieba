CREATE VIEW `view_chat` AS
  SELECT
    `a`.`cID`        AS `cID`,
    `a`.`cContent`   AS `cContent`,
    `a`.`cSendByUID` AS `cSendByUID`,
    `b`.`uName`      AS `userName`,
    `a`.`cSendTime`  AS `cSendTime`,
    `a`.`cSendIP`    AS `cSendIP`,
    `a`.`cType`      AS `cType`,
    `a`.`cIsReply`   AS `cIsReply`,
    `a`.`ReplyCID`   AS `ReplyCID`,
    `a`.`cStatus`    AS `cStatus`
  FROM `dbchattingroom`.`chat_room` `a`
    JOIN `dbchattingroom`.`user` `b`
  WHERE (`a`.`cSendByUID` = `b`.`uID`)